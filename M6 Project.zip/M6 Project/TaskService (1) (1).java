package test;
import java.util.HashMap;

import java.util.Map;
import test.Task;
import test.TaskServiceTest;



public class TaskService {

  private Map<String, Task> Tasks = new HashMap<>();



  public void addTask(Task Task) {

  if (Tasks.containsKey(Task.getTaskID())) {

  throw new IllegalArgumentException("Task ID already exists");

  }

  Tasks.put(Task.getTaskID(), Task);

  }



  public void deleteTask(String TaskID) {

  Tasks.remove(TaskID);

  }



  public void updateTask(String TaskID, String Name, String Description) {

  Task TaskS = Tasks.get(TaskID);

  if (TaskS == null) {

  throw new IllegalArgumentException("Task ID does not exist");

  }
  else {
	  TaskS.setName(Name);

	  TaskS.setDescription(Description);
  }


  }



}

