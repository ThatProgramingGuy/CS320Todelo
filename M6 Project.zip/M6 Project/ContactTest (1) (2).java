package test;

import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;


class ContactTest {

	@Test
	void Contact() {
		Contact contact = new Contact("MyTestWork", "Sun Czachu", "Tzach", "5747397879", "1516 Silver Lane");
			assertTrue(contact.getContactID().equals("MyTestWork"));
			assertTrue(contact.getFirstName().equals("Sun Czachu"));
			assertTrue(contact.getLastName().equals("Tzach"));
			assertTrue(contact.getPhone().equals("5747397879"));
			assertTrue(contact.getAddress().equals("1516 Silver Lane"));
	}
	@Test
	void ContactIDTest() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
				new Contact("MyTestError", "Sun Czachu", "Tzach", "5747397879", "1516 Silver Lane");
		});     }
	@Test
	void DataFirstNameTest() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
				new Contact("MyTestWord", "Sunst Czachu", "Tzach", "5747397879", "1516 Silver Lane");
		});     }
	@Test
	void DataLastNameTest() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
				new Contact("MyTestWork", "Sun Czachu", "Tzachenixowk", "5747397879", "1516 Silver Lane");
		});     }
	@Test
	void DataPhoneTest() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
				new Contact("MyTestWork", "Sun Czachu", "Tzach", "57473978798", "1516 Silver Lane");
		});     }
	@Test
	void DataAddressTest() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
				new Contact("MyTestWork", "Sun Czachu", "Tzach", "57473978798", "1516 Silverate Conichutto Terratocuchs Ishertut Drive");
		});     }
	}


