package test;
import java.util.HashMap;

import java.util.Map;
import test.Contact;
import test.ContactServiceTest;



public class ContactService {

  private Map<String, Contact> contacts = new HashMap<>();



  public void addContact(Contact contact) {

  if (contacts.containsKey(contact.getContactID())) {

  throw new IllegalArgumentException("Contact ID already exists");

  }

  contacts.put(contact.getContactID(), contact);

  }



  public void deleteContact(String contactID) {

  contacts.remove(contactID);

  }



  public void updateContact(String contactID, String firstName, String lastName, String phone, String address) {

  Contact contactS = contacts.get(contactID);

  if (contactS == null) {

  throw new IllegalArgumentException("Contact ID does not exist");

  }
  else {
	  contactS.setFirstName(firstName);

	  contactS.setLastName(lastName);

	  contactS.setPhone(phone);

	  contactS.setAddress(address);
  }


  }



}
