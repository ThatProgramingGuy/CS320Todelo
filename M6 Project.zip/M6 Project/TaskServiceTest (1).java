package test;

import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;


class TaskServiceTest extends TaskService {

	@Test
	void TaskServiceTesting() {
		Task Taskobj = new Task("Java 101", "Placeholder", "Placeholder");
		addTask(Taskobj);
			updateTask("Java 101", "Complete Module 6", "Complex Build Tasks");
			assertTrue(Taskobj.getName().equals("Complete Module 6"));
			assertTrue(Taskobj.getDescription().equals("Complex Build Tasks"));
	}
	@Test
	void DataNameTest() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			updateTask("Java 101", "Complete Module 6 Homework", "Complex Build Tasks");
		});     }
	@Test
	void DataDescriptionTest() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			updateTask("Java 101", "Complete Module 6", "Toledo: Complex Build Tasks With Junit and Appliction");
		});     }
	
	@Test
	void DeleteTaskTest() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			deleteTask("MyTestWork");
			updateTask("MyTestWork", "Sun Czachu", "Tzach");
		});     }
	}
