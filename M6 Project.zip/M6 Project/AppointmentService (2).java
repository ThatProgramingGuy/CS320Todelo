package test;
import java.time.LocalDate;
import java.util.HashMap;

import java.util.Map;
import test.Appointment;
import test.AppointmentServiceTest;



public class AppointmentService {

  private Map<String, Appointment> Appointments = new HashMap<>();



  public void addAppointment(Appointment Appointment) {

  if (Appointments.containsKey(Appointment.getAppointmentID())) {

  throw new IllegalArgumentException("Appointment ID already exists");

  }

  Appointments.put(Appointment.getAppointmentID(), Appointment);

  }



  public void deleteAppointment(String AppointmentID) {

  Appointments.remove(AppointmentID);

  }



  public void updateAppointment(String AppointmentID, LocalDate Date, String Description) {

  Appointment AppointmentS = Appointments.get(AppointmentID);

  if (AppointmentS == null) {

  throw new IllegalArgumentException("Appointment ID does not exist");

  }
  else {
	  AppointmentS.setDate(Date);

	  AppointmentS.setDescription(Description);

  }


  }



}

