package test;

import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;


class TaskTest {

	@Test
	void Task() {
		Task Task = new Task("Java TEST", "Complete Module 6", "Simple Junit Build Tasks");
			assertTrue(Task.getTaskID().equals("Java TEST"));
			assertTrue(Task.getName().equals("Complete Module 6"));
			assertTrue(Task.getDescription().equals("Simple Junit Build Tasks"));
	}
	@Test
	void TaskIDTest() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
				new Task("Java TEST Work", "Complete Module 6", "Tzach");
		});     }
	@Test
	void DataNameTest() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
				new Task("Java TEST Work", "Complete Module 6 Homework", "Simple Junit Build Tasks");
		});     }
	@Test
	void DataDescriptionTest() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
				new Task("Java TEST Work", "Complete Module 6", "Simple Junit Build Tasks and Others For Professor Todelo");
		});     }
	}


