package test;

import static org.junit.jupiter.api.Assertions.assertTrue;

import java.time.LocalDate;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;


class AppointmentTest {
    private LocalDate InputDateWork = LocalDate.parse("2023-10-09");
    private LocalDate InputDateError= LocalDate.parse("2020-10-09");
	@Test
	void Appointment() {		
		Appointment Appointment = new Appointment("MyTestWork", InputDateWork, "Basic Test Work");
			assertTrue(Appointment.getAppointmentID().equals("MyTestWork"));
			assertTrue(Appointment.getDate().equals(InputDateWork));
			assertTrue(Appointment.getDescription().equals("Basic Test Work"));
	}
	@Test
	void AppointmentIDTest() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
				new Appointment("MyTestError", InputDateWork, "Basic Test Work");
		});     }
	@Test
	void DataFirstNameTest() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
				new Appointment("MyTestWord", InputDateError, "Basic Test Work");
		});     }
	@Test
	void DataLastNameTest() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
				new Appointment("MyTestWork", InputDateWork, "Basic Test Work::::::::::::::::::::::::::::::::::::::::::::::::::::::");
		});     }
	}
