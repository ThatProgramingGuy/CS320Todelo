package test;

import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;


class ContactServiceTest extends ContactService {

	@Test
	void ContactServiceTesting() {
		Contact contactobj = new Contact("Java 101", "Sun Czachu", "Tzach", "5747397879", "1516 Silver Lane");
		addContact(contactobj);
			updateContact("Java 101", "Sun Cachu", "Tach", "4444446666", "1516 Silverate Lane");
			assertTrue(contactobj.getFirstName().equals("Sun Cachu"));
			assertTrue(contactobj.getLastName().equals("Tach"));
			assertTrue(contactobj.getPhone().equals("4444446666"));
			assertTrue(contactobj.getAddress().equals("1516 Silverate Lane"));

	}
	@Test
	void ContactIDTest() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			updateContact("MyTestError", "Sun Czachu", "Tzach", "5747397879", "1516 Silver Lane");
		});     }
	@Test
	void DataFirstNameTest() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			updateContact("MyTestWord", "Sunst Czachu", "Tzach", "5747397879", "1516 Silver Lane");
		});     }
	@Test
	void DataLastNameTest() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			updateContact("MyTestWork", "Sun Czachu", "Tzachenixowk", "5747397879", "1516 Silver Lane");
		});     }
	@Test
	void DataPhoneTest() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			updateContact("MyTestWork", "Sun Czachu", "Tzach", "57473978798", "1516 Silver Lane");
		});     }
	@Test
	void DataAddressTest() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			updateContact("MyTestWork", "Sun Czachu", "Tzach", "57473978798", "1516 Silverate Conichutto Terratocuchs Ishertut Drive");
		});     }
	
	@Test
	void DeletContactTest() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			deleteContact("MyTestWork");
			updateContact("MyTestWork", "Sun Czachu", "Tzach", "57473978798", "1516 Silverate Conichutto Terratocuchs Ishertut Drive");
		});     }
	}
