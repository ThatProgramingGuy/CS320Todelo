package test;

import static org.junit.jupiter.api.Assertions.assertTrue;

import java.time.LocalDate;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;


class AppointmentServiceTest extends AppointmentService {
	   private LocalDate InputDateWork1 = LocalDate.parse("2023-10-09");
	   private LocalDate InputDateWork2 = LocalDate.parse("2023-10-25");
	   private LocalDate InputDateError= LocalDate.parse("2020-10-09");
	@Test
	void AppointmentServiceTesting() {
		Appointment Appointmentobj = new Appointment("Java 101", InputDateWork1, "Basic Test Work");
		addAppointment(Appointmentobj);
			updateAppointment("Java 101", InputDateWork2, "Basic Test Work");
			assertTrue(Appointmentobj.getDate().equals(InputDateWork2));
			assertTrue(Appointmentobj.getDescription().equals("Basic Test Work"));

	}
	@Test
	void DataDateTest() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			updateAppointment("Java 101", InputDateError, "Tzach");
		});     }
	@Test
	void DataDescriptionTest() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			updateAppointment("Java 101", InputDateWork1, "Basic Test Work::::::::::::::::::::::::::::::::::::::::::::::::::::::");
		});     }
	@Test
	void DeleteAppointmentTest() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			deleteAppointment("Java 101");
			updateAppointment("Java 101", InputDateWork1, "Basic Test Work::::::::::::::::::::::::::::::::::::::::::::::::::::::");
		});     }

	}
